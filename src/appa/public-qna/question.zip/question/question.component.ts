import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/shared/auth.service';
import { ThemeService } from 'src/app/shared/theme.service';
import { OtherService } from 'src/app/shared/other.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss']
})
export class QuestionComponent implements OnInit {
  show:string='main';
  questionId:any;
  yourEmail:string;
  title:String='Forgot Password';
  constructor(
    private router:Router,
    private as:AuthService,     
    private ts:ThemeService,
    private os:OtherService,
    private actroute: ActivatedRoute,
    ) { }
 theme:boolean;
 color = 'accent';
 ngOnInit() {

   this.theme = this.ts.theme();
   this.getidFromUrl()
 }
 changeThene(){
   this.ts.changeTheme(this.theme);
 }
 getidFromUrl() {
  this.actroute.paramMap.subscribe(params => {
    this.questionId = params.get('id'); 
    console.log(this.questionId);
  })
}


}
